package com.cg.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.IUserDAO;

import com.cg.dao.UserDAOImpl;
import com.cg.dto.Airport;
import com.cg.dto.User;

@WebServlet("/CreateAccountServlet")
public class CreateAccountServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IUserDAO userDAO = new UserDAOImpl();
		RequestDispatcher dispatcher=null;
		PrintWriter out = response.getWriter();
		try{
			User user = new User();
			user.setUserName(request.getParameter("username"));
			System.out.println(1);
			user.setPassword(request.getParameter("password"));
			System.out.println(2);
			user.setUserType("usr");
			System.out.println(3);
			user.setEmail(request.getParameter("email"));
			System.out.println(4);
			user.setPhoneNumber(request.getParameter("phoneNumber"));
			
			System.out.println(5);
			user.setState(request.getParameter("state"));
			
			System.out.println("before add");
			int id = userDAO.addCustomer(user);
			
			System.out.println("after add");
			if(id != 0){
				//Print a success message and ask to login again
				dispatcher = request.getRequestDispatcher("login.jsp");
				dispatcher.forward(request, response);
			} else {
				out.print("Couldn't add the customer");
			}
		}catch(Exception e){
			System.out.println("In create account servlet");
			System.out.println(e.getMessage());
			
		}
		
	}
	
}