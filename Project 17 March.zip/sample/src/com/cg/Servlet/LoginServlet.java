package com.cg.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.ILoginDAO;
import com.cg.dao.LoginDAOImpl;
import com.cg.dao.UserDAOImpl;
import com.cg.dto.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ILoginDAO loginDAO = new LoginDAOImpl();
		RequestDispatcher dispatcher=null;
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println("in servlet");
		try{
			
			if(loginDAO.checkUser(username) != 0) {
				int userId = loginDAO.validate(username, password);
				if(userId != 0) {
					session.setAttribute("username", username);
					String roleCode = loginDAO.getRoleCode(userId);
					if(roleCode.equals("usr")) {
						dispatcher = request.getRequestDispatcher("customer.jsp");
						dispatcher.forward(request, response);
					}else if(roleCode.equals("adm")) {
						dispatcher = request.getRequestDispatcher("admin.jsp");
						dispatcher.forward(request, response);
					}
				}else {
					out.print("<font color='red'>Password is incorrect</font>");
					dispatcher = request.getRequestDispatcher("login.jsp");
					dispatcher.forward(request, response);
				}
			}else {
				System.out.println("In else");
				/*out.print("Please create an account");*/
				dispatcher = request.getRequestDispatcher("createAccount.jsp");
				System.out.println("brfore forward");
				dispatcher.forward(request, response);
				System.out.println("after forward");
			}
			
			
		}catch(Exception e) {
			System.out.println("error in servlet");
			System.out.println(e.getMessage());
			
		}
		
	}
	
}
