package com.cg.dao;

import javax.persistence.*;

import com.cg.JPAUtility.JPAUtility;
import com.cg.dto.User;
import com.cg.exceptions.AddCustomerException;

public class UserDAOImpl implements IUserDAO{
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	

	@Override
	public int addCustomer(User user) throws AddCustomerException {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
	
		transaction.begin();
		System.out.println("in add customer DAO");
		try {
			manager.persist(user);
			transaction.commit();
		} catch (PersistenceException e) {
			transaction.rollback();
			throw new AddCustomerException();
		} finally {
			manager.close();
			factory.close();
		}
		return user.getUserId();
	}
	

}

