package com.cg.dao;

import com.cg.dto.User;
import com.cg.exceptions.AddCustomerException;

public interface IUserDAO {

	public int addCustomer(User user) throws AddCustomerException;
}
