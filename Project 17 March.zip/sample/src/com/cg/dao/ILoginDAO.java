package com.cg.dao;

import com.cg.exceptions.SQLException;

public interface ILoginDAO {
	
	public int validate(String username,String password) throws SQLException;
	
	public String getRoleCode(int userId) throws SQLException;
	
	public int checkUser(String username) throws SQLException;

}
