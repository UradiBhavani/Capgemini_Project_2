package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.cg.JPAUtility.JPAUtility;
import com.cg.dto.User;
import com.cg.exceptions.SQLException;

public class LoginDAOImpl implements ILoginDAO{

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	@Override
	public int validate(String username, String password) throws SQLException {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		
		int userId = 0;
		try {
			Query query = manager.createQuery("select u from User u where u.userName=:username and u.password=:password");
			query.setParameter("username", username);
			query.setParameter("password", password);
			
			List<User> user = (List<User>)query.getResultList();	
			for (User userList : user) {
				userId = userList.getUserId();
			}
			
		} catch (Exception e) {
			throw new SQLException();
		}
		return userId;
	}

	@Override
	public String getRoleCode(int userId) throws SQLException {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		
		String roleCode = null;
		try {
			Query query = manager.createQuery("select userType from User u where u.userId=:userId");
			query.setParameter("userId", userId);
			
			roleCode = (String) query.getSingleResult();
		} catch (Exception e) {
			throw new SQLException();
		}
		
		return roleCode;
	}

	@Override
	public int checkUser(String username) throws SQLException {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		
		int userId = 0;
		System.out.println("In check user");
		try {
			
			Query query = manager.createQuery("select u from User u where u.userName=:username");
			query.setParameter("username", username);
			
			List<User> user = (List<User>)query.getResultList();
			System.out.println("list = "+user);
			for (User userList : user) {
				userId = userList.getUserId();
			}
			
		} catch (Exception e) {
			throw new SQLException();
		}
		System.out.println("id = "+userId);
		return userId;
	}
	
	

}
