package com.cg.JPAUtility;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtility {
static EntityManagerFactory factory = null;
	
	static {
		factory = Persistence.createEntityManagerFactory("flight_bu");
	}
	
	
	public static EntityManagerFactory getFactory() {
		return factory;
	}

}
