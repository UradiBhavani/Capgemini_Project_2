package com.cg.exceptions;

public class SQLException extends Exception{
	
	public String getMessage() {
		return "Error in the query";
	}

}
