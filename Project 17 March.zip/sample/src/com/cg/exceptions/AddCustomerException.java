package com.cg.exceptions;

public class AddCustomerException extends Exception{
	public String getMessage() {
		return "Error in the persistence";
	}

}
