package com.cg.dto;

import javax.persistence.Entity;
import javax.persistence.Table;

public class Passenger {
	
	private int pnrNumber;
	private String passengerName;
	private int age;
	private long UIN;
	private String state;
	private double luggage;
	private String gender;
	public Passenger(int pnrNumber, String passengerName, int age, long uIN, String state, double luggage,
			String gender) {
		super();
		this.pnrNumber = pnrNumber;
		this.passengerName = passengerName;
		this.age = age;
		UIN = uIN;
		this.state = state;
		this.luggage = luggage;
		this.gender = gender;
	}
	public Passenger() {
		super();
	}
	public int getPnrNumber() {
		return pnrNumber;
	}
	public void setPnrNumber(int pnrNumber) {
		this.pnrNumber = pnrNumber;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getUIN() {
		return UIN;
	}
	public void setUIN(long uIN) {
		UIN = uIN;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getLuggage() {
		return luggage;
	}
	public void setLuggage(double luggage) {
		this.luggage = luggage;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Passenger [pnrNumber=" + pnrNumber + ", passengerName=" + passengerName + ", age=" + age + ", UIN="
				+ UIN + ", state=" + state + ", luggage=" + luggage + ", gender=" + gender + "]";
	}
	

}
