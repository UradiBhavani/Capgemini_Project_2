package com.cg.dto;

import javax.persistence.Entity;
import javax.persistence.Table;
/*
@Entity
@Table(name="flight")*/
public class Flight {
	private int flightNumber;
	private String flightModel;
	private String carrierName;
	private int seatCapacity;
	private double ticketCost;
	public Flight(int flightNumber, String flightModel, String carrierName, int seatCapacity, double ticketCost) {
		super();
		this.flightNumber = flightNumber;
		this.flightModel = flightModel;
		this.carrierName = carrierName;
		this.seatCapacity = seatCapacity;
		this.ticketCost = ticketCost;
	}
	public Flight() {
		super();
	}
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getFlightModel() {
		return flightModel;
	}
	public void setFlightModel(String flightModel) {
		this.flightModel = flightModel;
	}
	public String getCarrierName() {
		return carrierName;
	}
	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}
	public int getSeatCapacity() {
		return seatCapacity;
	}
	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}
	public double getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}
	@Override
	public String toString() {
		return "Flight [flightNumber=" + flightNumber + ", flightModel=" + flightModel + ", carrierName=" + carrierName
				+ ", seatCapacity=" + seatCapacity + ", ticketCost=" + ticketCost + "]";
	}
	
	
	
}
