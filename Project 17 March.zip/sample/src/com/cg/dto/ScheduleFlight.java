package com.cg.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
/*@Entity
@Table(name="scheduleflight")*/
public class ScheduleFlight {
	private int flightNumber;
	private int availableSeats;
	private double ticketCost;
	private String sourceAirport;
	private String destinationAirport;
	private Date departureDatetime;
	private Date arrivalDateTime;
	private String scheduleFlightState;
	
	
	public ScheduleFlight(int flightNumber, int availableSeats, double ticketCost, String sourceAirport,
			String destinationAirport, Date departureDatetime, Date arrivalDateTime, String scheduleFlightState) {
		super();
		this.flightNumber = flightNumber;
		this.availableSeats = availableSeats;
		this.ticketCost = ticketCost;
		this.sourceAirport = sourceAirport;
		this.destinationAirport = destinationAirport;
		this.departureDatetime = departureDatetime;
		this.arrivalDateTime = arrivalDateTime;
		this.scheduleFlightState = scheduleFlightState;
	}
	
	public ScheduleFlight() {
		super();
	}
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public double getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}
	public String getSourceAirport() {
		return sourceAirport;
	}
	public void setSourceAirport(String sourceAirport) {
		this.sourceAirport = sourceAirport;
	}
	public String getDestinationAirport() {
		return destinationAirport;
	}
	public void setDestinationAirport(String destinationAirport) {
		this.destinationAirport = destinationAirport;
	}

	public Date getDepartureDatetime() {
		return departureDatetime;
	}

	public void setDepartureDatetime(Date departureDatetime) {
		this.departureDatetime = departureDatetime;
	}

	public Date getArrivalDateTime() {
		return arrivalDateTime;
	}

	public void setArrivalDateTime(Date arrivalDateTime) {
		this.arrivalDateTime = arrivalDateTime;
	}

	public String getScheduleFlightState() {
		return scheduleFlightState;
	}

	public void setScheduleFlightState(String scheduleFlightState) {
		this.scheduleFlightState = scheduleFlightState;
	}

	@Override
	public String toString() {
		return "ScheduleFlight [flightNumber=" + flightNumber + ", availableSeats=" + availableSeats + ", ticketCost="
				+ ticketCost + ", sourceAirport=" + sourceAirport + ", destinationAirport=" + destinationAirport
				+ ", departureDatetime=" + departureDatetime + ", arrivalDateTime=" + arrivalDateTime
				+ ", scheduleFlightState=" + scheduleFlightState + "]";
	}
	
	
	
	
}
